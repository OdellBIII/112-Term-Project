- Description: 
	Jerry�s Great Climb is a video game with the objective of avoiding the
bottom of screen by climbing stacked objects as they appear from the top of the screen. Your
score is determined by what elevation is achieved each turn.
- Getting Up and Running:
	Once the zip file has been downloaded from Autolab, unzip all files into the same file
with the name of your choosing. Open the main.py file in your code editor and run. Be sure to have
Pygame already installed.
- How to install necessary libraries:
	Pygame is the only libary which may need to be installed for this application to work.
- Short commands to see features:

	- Press the "1" key to drop a double jump power up.
	- Press the "2" key to drop a high jump power up.